./objects/met2.o: met2.c met2.h gen.h led.h usart.h
