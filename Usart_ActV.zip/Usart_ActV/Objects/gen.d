./objects/gen.o: gen.c gen.h
