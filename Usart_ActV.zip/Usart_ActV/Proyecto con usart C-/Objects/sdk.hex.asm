; Disassembled code
