./objects/system_stm32f10x.o: RTE\Device\STM32F103C8\system_stm32f10x.c \
  C:\Users\yalis\AppData\Local\Arm\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\stm32f10x.h \
  RTE\_sdk\RTE_Components.h \
  C:\Users\yalis\AppData\Local\Arm\Packs\ARM\CMSIS\6.2.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\yalis\AppData\Local\Arm\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\system_stm32f10x.h
