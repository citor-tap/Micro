./objects/main.o: main.c gpio.h ext_in.h i2c.h
